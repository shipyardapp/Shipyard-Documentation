require 'json'
require 'uri'
require 'net/http'
require 'yell'


# get the top stories
list_url = URI("https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty")

http = Net::HTTP.new(list_url.host, list_url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(list_url)
request.body = "{}"

response = http.request(request)
data = JSON.parse(response.body)

# get the top story by ID from index 0
item_url_string = "https://hacker-news.firebaseio.com/v0/item/%s.json?print=pretty" % [data[0]]
item_url = URI(item_url_string)

http = Net::HTTP.new(item_url.host, item_url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE
	
request = Net::HTTP::Get.new(item_url)
request.body = "{}"

response = http.request(request)
data = JSON.parse(response.body)

logger = Yell.new STDOUT

# print output
logger.info 'Top story on Hacker News stats'
logger.info 'title:', data['title']
logger.info 'score:', data['score']
logger.info 'link:', data['url']