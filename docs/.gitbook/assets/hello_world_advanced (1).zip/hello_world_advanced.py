import os
import datetime
import argparse
import random
import requests

# Set up the script to parse arguments
parser = argparse.ArgumentParser()

# Set two arguments, one that uses flags and one that is positional.
parser.add_argument('--herring', dest='herring', action='store_false')
parser.add_argument('--cat_fact', '-f', dest='cat_fact', action='store_true')
parser.add_argument('custom_text')

# Parse the arguments so that the values can be referenced.
args = parser.parse_args()

# Pull in the environment variable set in the tutorial.
your_name = os.environ.get('YOUR_NAME')

# Set the red herring which gets disabled by the --herring argument
red_herring = 'When following the tutorial, this line won\'t print.'

# Set the runtime of the Log.
run_time = datetime.datetime.now()

# Set Shipyard platform variables as variables.
vessel_id = os.environ.get('SHIPYARD_VESSEL_ID')
vessel_name = os.environ.get('SHIPYARD_VESSEL_NAME')
log_id = os.environ.get('SHIPYARD_LOG_ID')
project_id = os.environ.get('SHIPYARD_PROJECT_ID')
org_name = os.environ.get('SHIPYARD_ORG_NAME')

shipyard_url_structure = f'https://app.shipyardapp.com/{org_name}/projects/{project_id}/vessels/{vessel_id}/logs/{log_id}'

#Connect to a cat facts api and grab a fact.
url = 'https://cat-fact.herokuapp.com/facts'
cat_facts_json = requests.get(url).json()
cat_fact = cat_facts_json['all'][random.randrange(0,10)]['text']

# Run print statements
print('Hello, {your_name}!\n')

print(f'Your Vessel, {vessel_name}, was run at {run_time}.')
print(f'For more details, visit {shipyard_url_structure}\n')

print('Below is the custom text you wrote:')
print(args.custom_text + '\n')

if args.cat_fact:
	print('You wanted a cat fact? Here you go.')
	print(cat_fact + '\n')
else:
	print('Not in a mood for a cat fact? We all have those days...\n')

# Check to see if the --herring flag is present.
if args.herring:
	pass
else:
	print(red_herring)

