package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"

	log "github.com/sirupsen/logrus"
)

func main() {
	// get the top stories
	resp, err := http.Get("https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty")
	if err != nil {
		log.Fatal("get top stories error:", err.Error())
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatal("read body error:", err.Error())
	}

	ids := []int{}
	if err := json.Unmarshal(body, &ids); err != nil {
		log.Fatal("unmarshal top stories error:", err.Error())
	}

	// get the top story by ID from index 0
	resp, err = http.Get(fmt.Sprintf("https://hacker-news.firebaseio.com/v0/item/%d.json?print=pretty", ids[0]))
	if err != nil {
		log.Fatal("get item error:", err.Error())
	}

	body, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatal("read body error:", err.Error())
	}

	content := map[string]interface{}{}
	if err := json.Unmarshal(body, &content); err != nil {
		log.Fatal("unmarshal item error:", err.Error())
	}

	// print output
	log.Println("Top story on Hacker News stats")
	log.Println("title:", content["title"])
	log.Println("score:", content["score"])
	log.Println("link:", content["url"])
}
