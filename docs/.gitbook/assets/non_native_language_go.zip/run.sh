# initialize Go modules
go mod init example.com

# install logging dependency
go get github.com/sirupsen/logrus

# run script
go run script.go